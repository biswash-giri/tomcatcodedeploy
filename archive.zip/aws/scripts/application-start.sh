#!/bin/bash
set -xe

# Start Tomcat, the application server.
sudo service tomcat9 start